import {
  ArrowRight,
  Calendar,
  MapPin,
  Trophy,
  Cpu,
  Radio,
  Users,
  Globe2,
  Sparkles,
  Quote,
} from "lucide-react";
import { useEffect, useRef, useState } from "react";
import SectionHeading from "../components/SectionHeading";
import {
  ACHIEVEMENTS,
  EVENTS,
  PARTNERS,
  SOCIETIES,
  STATS,
  TEAM,
  TESTIMONIALS,
  type Page,
} from "../data";
import { useCountdown, useCountUp } from "../hooks";

export default function Home({
  onNavigate,
  onJoin,
}: {
  onNavigate: (p: Page) => void;
  onJoin: () => void;
}) {
  return (
    <>
      <Hero onNavigate={onNavigate} onJoin={onJoin} />
      <Marquee />
      <Stats />
      <AboutPreview onNavigate={onNavigate} />
      <SocietiesPreview onNavigate={onNavigate} />
      <EventsPreview onNavigate={onNavigate} />
      <Achievements />
      <TeamPreview onNavigate={onNavigate} />
      <Voices />
      <Partners />
      <Cta onJoin={onJoin} />
    </>
  );
}

function Hero({
  onNavigate,
  onJoin,
}: {
  onNavigate: (p: Page) => void;
  onJoin: () => void;
}) {
  const c = useCountdown(new Date("2026-03-14T09:00:00+05:30"));

  return (
    <section className="relative min-h-screen overflow-hidden">
      <img
        src="/images/hero.jpg"
        alt="RajaRajeswari College of Engineering campus"
        className="absolute inset-0 h-full w-full object-cover"
      />
      <div className="absolute inset-0 bg-gradient-to-b from-[#050a12]/70 via-[#050a12]/78 to-[#050a12]" />
      <div className="absolute inset-0 circuit-grid opacity-40" />
      <div className="glow-orb absolute top-24 left-10 h-72 w-72 rounded-full bg-ieee/40" />
      <div className="glow-orb absolute right-0 bottom-10 h-80 w-80 rounded-full bg-cyan-500/20" />

      <div className="relative mx-auto flex min-h-screen max-w-7xl flex-col justify-center px-5 pt-24 pb-16">
        <div className="inline-flex w-fit items-center gap-2 rounded-full border border-cyan-400/30 bg-cyan-400/10 px-3 py-1 text-[11px] font-semibold uppercase tracking-[0.22em] text-cyan-200">
          <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-cyan-300" />
          IEEE Bangalore Section · STB20210
        </div>

        <h1 className="font-display animate-fade-up mt-6 max-w-4xl text-4xl font-semibold leading-[1.05] tracking-tight text-white delay-1 sm:text-6xl lg:text-7xl">
          Advancing technology
          <span className="block bg-gradient-to-r from-cyan-300 via-white to-gold bg-clip-text text-transparent">
            for humanity.
          </span>
        </h1>
        <p className="animate-fade-up mt-6 max-w-xl text-lg leading-relaxed text-slate-300 delay-2">
          The IEEE Student Branch of RajaRajeswari College of Engineering — 520 engineers, eight
          societies, and a decade of labs, papers, and hackathons on Mysore Road, Bengaluru.
        </p>

        <div className="animate-fade-up mt-8 flex flex-wrap gap-3 delay-3">
          <button
            onClick={onJoin}
            className="inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-ieee to-cyan-400 px-6 py-3 text-sm font-semibold text-white shadow-lg shadow-cyan-500/25"
          >
            Become a member <ArrowRight className="h-4 w-4" />
          </button>
          <button
            onClick={() => onNavigate("events")}
            className="inline-flex items-center gap-2 rounded-full border border-white/20 bg-white/5 px-6 py-3 text-sm font-semibold text-white backdrop-blur"
          >
            Explore events
          </button>
        </div>

        <div className="animate-fade-up mt-12 grid max-w-xl grid-cols-4 gap-3 delay-4">
          {[
            ["Days", c.days],
            ["Hours", c.hours],
            ["Min", c.minutes],
            ["Sec", c.seconds],
          ].map(([label, n]) => (
            <div
              key={String(label)}
              className="rounded-2xl border border-white/10 bg-black/30 p-3 text-center backdrop-blur"
            >
              <div className="font-display text-2xl font-semibold text-white md:text-3xl">
                {String(n).padStart(2, "0")}
              </div>
              <div className="mt-1 text-[10px] uppercase tracking-[0.2em] text-cyan-300">{label}</div>
            </div>
          ))}
        </div>
        <p className="mt-3 text-xs uppercase tracking-[0.22em] text-slate-400">
          NEXUS 2026 · 14–16 March · National Hackathon
        </p>
      </div>
    </section>
  );
}

function Marquee() {
  const items = [...PARTNERS, ...PARTNERS];
  return (
    <div className="border-y border-cyan-400/10 bg-[#08111c] py-4 overflow-hidden">
      <div className="animate-marquee flex w-max gap-10 whitespace-nowrap">
        {items.map((p, i) => (
          <span key={i} className="text-xs font-semibold uppercase tracking-[0.28em] text-slate-500">
            {p} <span className="mx-4 text-cyan-700">◆</span>
          </span>
        ))}
      </div>
    </div>
  );
}

function Stats() {
  const ref = useRef<HTMLDivElement>(null);
  const [on, setOn] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const io = new IntersectionObserver(([e]) => e.isIntersecting && setOn(true), { threshold: 0.4 });
    io.observe(el);
    return () => io.disconnect();
  }, []);

  return (
    <section ref={ref} className="relative py-16">
      <div className="mx-auto grid max-w-6xl grid-cols-2 gap-4 px-5 md:grid-cols-4">
        {STATS.map((s) => (
          <StatCard key={s.label} end={s.value} suffix={s.suffix} label={s.label} on={on} />
        ))}
      </div>
    </section>
  );
}

function StatCard({
  end,
  suffix,
  label,
  on,
}: {
  end: number;
  suffix: string;
  label: string;
  on: boolean;
}) {
  const n = useCountUp(end, on);
  return (
    <div className="rounded-3xl border border-cyan-400/15 bg-gradient-to-b from-white/5 to-transparent p-6 text-center">
      <div className="font-display text-4xl font-semibold text-white md:text-5xl">
        {n}
        {suffix}
      </div>
      <div className="mt-2 text-xs uppercase tracking-[0.2em] text-slate-400">{label}</div>
    </div>
  );
}

function AboutPreview({ onNavigate }: { onNavigate: (p: Page) => void }) {
  return (
    <section className="relative py-20">
      <div className="mx-auto grid max-w-7xl items-center gap-12 px-5 lg:grid-cols-2">
        <div className="relative">
          <div className="absolute -inset-4 rounded-[2rem] bg-gradient-to-br from-ieee/40 to-cyan-400/20 blur-2xl" />
          <img
            src="/images/about-lab.jpg"
            alt="Students in the IEEE hardware studio"
            className="relative h-[420px] w-full rounded-[2rem] object-cover ring-1 ring-white/10"
          />
          <div className="absolute bottom-5 left-5 rounded-2xl bg-[#050a12]/85 px-4 py-3 backdrop-blur">
            <p className="text-[10px] uppercase tracking-[0.2em] text-cyan-300">Since 2014</p>
            <p className="font-display text-lg text-white">Chartered under Bangalore Section</p>
          </div>
        </div>
        <div>
          <p className="text-[11px] font-semibold uppercase tracking-[0.32em] text-cyan-300">The branch</p>
          <h2 className="font-display mt-3 text-4xl font-semibold text-white md:text-5xl">
            A professional society on an engineering campus.
          </h2>
          <p className="mt-5 text-slate-400 leading-relaxed">
            IEEE is the world’s largest technical professional organization. At RRCE we run it as a
            serious student branch — not a fest committee. Chapters meet weekly. Papers go to
            Xplore. Projects ship to villages through SIGHT. Officers are elected, budgets are
            audited, and first-years are expected to build.
          </p>
          <ul className="mt-6 grid gap-3 text-sm text-slate-300">
            {[
              "Aligned with IEEE Bangalore Section & Region 10",
              "Eight active societies and affinity groups",
              "Faculty counselor in every major decision",
            ].map((t) => (
              <li key={t} className="flex items-start gap-2">
                <span className="mt-1 h-1.5 w-1.5 rounded-full bg-gold" />
                {t}
              </li>
            ))}
          </ul>
          <button
            onClick={() => onNavigate("about")}
            className="mt-8 inline-flex items-center gap-2 text-sm font-semibold text-cyan-300"
          >
            Read the story <ArrowRight className="h-4 w-4" />
          </button>
        </div>
      </div>
    </section>
  );
}

function SocietiesPreview({ onNavigate }: { onNavigate: (p: Page) => void }) {
  return (
    <section className="relative py-20">
      <div className="mx-auto max-w-7xl px-5">
        <SectionHeading
          kicker="Chapters"
          title="Eight doors into the profession."
          text="Join the branch, then pick the society that matches the work you want to do."
        />
        <div className="mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {SOCIETIES.map((s) => (
            <button
              key={s.id}
              onClick={() => onNavigate("societies")}
              className="group rounded-3xl border border-white/10 bg-white/[0.03] p-6 text-left transition hover:-translate-y-1 hover:border-cyan-400/30"
            >
              <div
                className="flex h-11 w-11 items-center justify-center rounded-2xl font-display text-sm font-bold text-white"
                style={{ background: s.color }}
              >
                {s.short}
              </div>
              <h3 className="font-display mt-4 text-lg text-white">{s.name}</h3>
              <p className="mt-2 line-clamp-3 text-sm text-slate-400">{s.desc}</p>
              <p className="mt-4 text-xs uppercase tracking-[0.18em] text-cyan-300">{s.members} members</p>
            </button>
          ))}
        </div>
      </div>
    </section>
  );
}

function EventsPreview({ onNavigate }: { onNavigate: (p: Page) => void }) {
  const upcoming = EVENTS.filter((e) => e.status === "upcoming").slice(0, 3);
  return (
    <section className="py-20">
      <div className="mx-auto max-w-7xl px-5">
        <div className="flex flex-wrap items-end justify-between gap-4">
          <SectionHeading kicker="Calendar" title="What the branch is building next." />
          <button
            onClick={() => onNavigate("events")}
            className="text-sm font-semibold text-cyan-300"
          >
            Full calendar →
          </button>
        </div>
        <div className="mt-12 grid gap-6 lg:grid-cols-3">
          {upcoming.map((e) => (
            <article
              key={e.id}
              className="overflow-hidden rounded-3xl border border-white/10 bg-[#0c1826]"
            >
              <div className="relative h-48">
                <img src={e.image} alt={e.title} className="h-full w-full object-cover" />
                <span className="absolute top-3 left-3 rounded-full bg-ieee px-3 py-1 text-[11px] font-semibold uppercase tracking-wider text-white">
                  {e.type}
                </span>
              </div>
              <div className="p-6">
                <h3 className="font-display text-xl text-white">{e.title}</h3>
                <p className="mt-3 flex items-center gap-2 text-sm text-slate-400">
                  <Calendar className="h-4 w-4 text-cyan-400" /> {e.date}
                  {e.end ? ` – ${e.end}` : ""}
                </p>
                <p className="mt-1 flex items-center gap-2 text-sm text-slate-400">
                  <MapPin className="h-4 w-4 text-cyan-400" /> {e.venue}
                </p>
                <p className="mt-3 text-sm leading-relaxed text-slate-400">{e.desc}</p>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}

function Achievements() {
  return (
    <section className="py-20">
      <div className="mx-auto max-w-7xl px-5">
        <SectionHeading
          kicker="Record"
          title="Awards the section actually notices."
          text="Not participation certificates — competitive IEEE awards at section, region, and MGA level."
        />
        <div className="mt-12 grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {ACHIEVEMENTS.map((a) => (
            <div
              key={a.title}
              className="flex gap-4 rounded-3xl border border-gold/20 bg-gold/5 p-5"
            >
              <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-gold/20 text-gold">
                <Trophy className="h-5 w-5" />
              </div>
              <div>
                <p className="font-display text-lg text-white">{a.title}</p>
                <p className="text-sm text-slate-400">
                  {a.org} · {a.year}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function TeamPreview({ onNavigate }: { onNavigate: (p: Page) => void }) {
  return (
    <section className="py-20">
      <div className="mx-auto max-w-7xl px-5">
        <SectionHeading
          kicker="Execom 2025–26"
          title="The people who keep the branch honest."
        />
        <div className="mt-12 grid grid-cols-2 gap-4 md:grid-cols-4 lg:grid-cols-7">
          {TEAM.map((m) => (
            <div key={m.name} className="text-center">
              <img
                src={m.img}
                alt={m.name}
                className="mx-auto h-28 w-28 rounded-full object-cover ring-2 ring-cyan-400/30 md:h-32 md:w-32"
              />
              <p className="font-display mt-3 text-sm text-white">{m.name}</p>
              <p className="text-[11px] text-cyan-300">{m.role}</p>
            </div>
          ))}
        </div>
        <div className="mt-10 text-center">
          <button onClick={() => onNavigate("team")} className="text-sm font-semibold text-cyan-300">
            Meet the full team →
          </button>
        </div>
      </div>
    </section>
  );
}

function Voices() {
  return (
    <section className="py-20">
      <div className="mx-auto max-w-7xl px-5">
        <SectionHeading kicker="Voices" title="What membership actually feels like." />
        <div className="mt-12 grid gap-6 md:grid-cols-3">
          {TESTIMONIALS.map((t) => (
            <blockquote
              key={t.name}
              className="rounded-3xl border border-white/10 bg-white/[0.03] p-7"
            >
              <Quote className="h-6 w-6 text-cyan-400/70" />
              <p className="mt-4 text-slate-300 leading-relaxed">“{t.quote}”</p>
              <footer className="mt-6">
                <p className="font-display text-white">{t.name}</p>
                <p className="text-xs text-slate-500">{t.role}</p>
              </footer>
            </blockquote>
          ))}
        </div>
      </div>
    </section>
  );
}

function Partners() {
  const icons = [Cpu, Radio, Users, Globe2, Sparkles, Trophy];
  return (
    <section className="py-16">
      <div className="mx-auto flex max-w-5xl flex-wrap justify-center gap-3 px-5">
        {icons.map((Icon, i) => (
          <div
            key={i}
            className="flex h-14 w-14 items-center justify-center rounded-2xl border border-white/10 text-slate-500"
          >
            <Icon className="h-5 w-5" />
          </div>
        ))}
      </div>
    </section>
  );
}

function Cta({ onJoin }: { onJoin: () => void }) {
  return (
    <section className="px-5 pb-24">
      <div className="relative mx-auto max-w-6xl overflow-hidden rounded-[2.2rem] border border-cyan-400/20 bg-gradient-to-br from-[#002855] via-ieee to-cyan-600 px-8 py-16 text-center">
        <div className="absolute inset-0 circuit-grid opacity-30" />
        <div className="relative">
          <p className="text-[11px] font-semibold uppercase tracking-[0.32em] text-cyan-100">
            Membership 2026
          </p>
          <h2 className="font-display mx-auto mt-3 max-w-2xl text-3xl font-semibold text-white md:text-5xl">
            The syllabus will not make you an IEEE engineer. The branch might.
          </h2>
          <button
            onClick={onJoin}
            className="mt-8 rounded-full bg-white px-7 py-3 text-sm font-semibold text-navy"
          >
            Join the student branch
          </button>
        </div>
      </div>
    </section>
  );
}
