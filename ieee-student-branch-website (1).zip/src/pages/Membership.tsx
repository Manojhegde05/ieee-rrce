import { ChevronDown, Check } from "lucide-react";
import { useEffect, useState } from "react";
import PageHero from "../components/PageHero";
import IeeeJoin from "../components/IeeeJoin";
import { BENEFITS, FAQS } from "../data";
import { fetchSpectrumNews, type SpectrumItem } from "../backend/ieee";

export default function Membership({ onJoin }: { onJoin: () => void }) {
  const [open, setOpen] = useState(0);
  const [news, setNews] = useState<SpectrumItem[]>([]);

  useEffect(() => {
    fetchSpectrumNews(4).then(setNews).catch(() => setNews([]));
  }, []);

  return (
    <>
      <PageHero
        kicker="Membership"
        title="One number. A global profession."
        text="Student membership is billed yearly on the official IEEE website. This branch only keeps the RajaRajeswari College of Engineering roster (STB20210)."
      />

      <section className="pt-12">
        <div className="mx-auto max-w-4xl px-5">
          <IeeeJoin />
        </div>
      </section>

      <section className="py-16">
        <div className="mx-auto grid max-w-7xl gap-6 px-5 md:grid-cols-3">
          {BENEFITS.map((b) => (
            <div key={b.title} className="rounded-3xl border border-white/10 bg-[#0c1826] p-6">
              <div className="flex h-9 w-9 items-center justify-center rounded-full bg-cyan-400/15 text-cyan-300">
                <Check className="h-4 w-4" />
              </div>
              <h3 className="font-display mt-4 text-xl text-white">{b.title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-slate-400">{b.text}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="py-10">
        <div className="mx-auto grid max-w-6xl gap-6 px-5 lg:grid-cols-3">
          {[
            { name: "Student member", price: "$32", note: "IEEE basic dues / year", items: ["IEEE.org account", "Spectrum digital", "SB voting rights", "Event priority"] },
            { name: "Student + society", price: "$40+", note: "Add CS, PES, RAS…", items: ["Everything in basic", "Society magazines", "Chapter voting", "Paper contests"] },
            { name: "WIE affinity", price: "+$0–5", note: "Open to all genders", items: ["WIE summit access", "Mentorship circle", "Leadership lab", "Travel grants"] },
          ].map((p, i) => (
            <div
              key={p.name}
              className={`rounded-3xl border p-7 ${
                i === 1 ? "border-cyan-400/40 bg-ieee/20" : "border-white/10 bg-[#0c1826]"
              }`}
            >
              <p className="text-xs uppercase tracking-[0.2em] text-cyan-300">{p.name}</p>
              <p className="font-display mt-3 text-4xl text-white">{p.price}</p>
              <p className="text-sm text-slate-500">{p.note}</p>
              <ul className="mt-6 space-y-2 text-sm text-slate-300">
                {p.items.map((it) => (
                  <li key={it} className="flex gap-2">
                    <Check className="h-4 w-4 text-cyan-400" /> {it}
                  </li>
                ))}
              </ul>
              <button
                onClick={onJoin}
                className="mt-8 w-full rounded-full bg-white/10 py-3 text-sm font-semibold text-white hover:bg-white/20"
              >
                Start application
              </button>
            </div>
          ))}
        </div>
      </section>

      <section className="py-16">
        <div className="mx-auto max-w-3xl px-5">
          <h2 className="font-display text-center text-3xl text-white">How you actually join</h2>
          <ol className="mt-10 space-y-4">
            {[
              "Submit the campus form so we know you exist.",
              "Join as a Student Member on the official IEEE.org website.",
              "Paste your IEEE member number from myIEEE into the RRCE student portal.",
              "Collect your ID sticker at the ECE block, Fridays 4–6 pm.",
            ].map((s, i) => (
              <li key={s} className="flex gap-4 rounded-2xl border border-white/10 p-4">
                <span className="font-display text-2xl text-cyan-300">0{i + 1}</span>
                <p className="text-slate-300">{s}</p>
              </li>
            ))}
          </ol>
        </div>
      </section>

      {news.length > 0 && (
        <section className="pb-16">
          <div className="mx-auto max-w-3xl px-5">
            <h2 className="font-display text-center text-3xl text-white">From IEEE Spectrum</h2>
            <ul className="mt-8 space-y-3">
              {news.map((n) => (
                <li key={n.link}>
                  <a
                    href={n.link}
                    target="_blank"
                    rel="noreferrer"
                    className="block rounded-2xl border border-white/10 p-4 text-sm text-slate-300 transition hover:border-cyan-400/30 hover:text-white"
                  >
                    {n.title}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </section>
      )}

      <section className="pb-24">
        <div className="mx-auto max-w-3xl px-5">
          <h2 className="font-display text-center text-3xl text-white">Questions we get every August</h2>
          <div className="mt-8 divide-y divide-white/10 rounded-3xl border border-white/10">
            {FAQS.map((f, i) => (
              <button
                key={f.q}
                onClick={() => setOpen(open === i ? -1 : i)}
                className="w-full px-6 py-5 text-left"
              >
                <div className="flex items-center justify-between gap-4">
                  <span className="font-medium text-white">{f.q}</span>
                  <ChevronDown className={`h-4 w-4 text-cyan-300 transition ${open === i ? "rotate-180" : ""}`} />
                </div>
                {open === i && <p className="mt-3 text-sm leading-relaxed text-slate-400">{f.a}</p>}
              </button>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}
