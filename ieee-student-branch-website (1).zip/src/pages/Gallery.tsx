import { X } from "lucide-react";
import { useState } from "react";
import PageHero from "../components/PageHero";
import { GALLERY } from "../data";

export default function Gallery() {
  const [active, setActive] = useState<number | null>(null);
  const tags = ["All", ...Array.from(new Set(GALLERY.map((g) => g.tag)))];
  const [tag, setTag] = useState("All");
  const list = tag === "All" ? GALLERY : GALLERY.filter((g) => g.tag === tag);

  return (
    <>
      <PageHero
        kicker="Gallery"
        title="Labs, nights, and the occasional trophy."
        text="A living archive of IEEE SB RRCE — lectures, hardware sprints, and the campus on IEEE Day."
      />
      <section className="py-14">
        <div className="mx-auto max-w-7xl px-5">
          <div className="flex flex-wrap gap-2">
            {tags.map((t) => (
              <button
                key={t}
                onClick={() => setTag(t)}
                className={`rounded-full px-4 py-2 text-xs font-semibold uppercase tracking-wider ${
                  tag === t ? "bg-ieee text-white" : "border border-white/10 text-slate-400"
                }`}
              >
                {t}
              </button>
            ))}
          </div>
          <div className="mt-8 columns-1 gap-4 sm:columns-2 lg:columns-3">
            {list.map((g) => {
              const idx = GALLERY.indexOf(g);
              return (
                <button
                  key={g.src}
                  onClick={() => setActive(idx)}
                  className="mb-4 block w-full overflow-hidden rounded-2xl"
                >
                  <img src={g.src} alt={g.title} className="w-full object-cover transition hover:scale-[1.03]" />
                </button>
              );
            })}
          </div>
        </div>
      </section>

      {active !== null && (
        <div className="fixed inset-0 z-[70] flex items-center justify-center p-4">
          <button className="absolute inset-0 bg-black/80" onClick={() => setActive(null)} />
          <div className="relative max-w-4xl">
            <img src={GALLERY[active].src} alt={GALLERY[active].title} className="max-h-[80vh] rounded-2xl" />
            <p className="mt-3 text-center text-sm text-slate-300">
              {GALLERY[active].title} · {GALLERY[active].tag}
            </p>
            <button
              onClick={() => setActive(null)}
              className="absolute -top-3 -right-3 rounded-full bg-white p-2 text-navy"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        </div>
      )}
    </>
  );
}
