import { Compass, Eye, HeartHandshake, Landmark } from "lucide-react";
import PageHero from "../components/PageHero";
import SectionHeading from "../components/SectionHeading";
import { TIMELINE } from "../data";

export default function About() {
  return (
    <>
      <PageHero
        kicker="About the branch"
        title="IEEE at RajaRajeswari College of Engineering."
        text="A chartered student branch of the world’s largest technical professional organization — run like a professional society, hosted on Mysore Road, Bengaluru."
      />

      <section className="py-20">
        <div className="mx-auto grid max-w-7xl items-center gap-12 px-5 lg:grid-cols-2">
          <img
            src="/images/about-lab.jpg"
            alt="IEEE hardware studio"
            className="h-[460px] w-full rounded-[2rem] object-cover ring-1 ring-white/10"
          />
          <div>
            <p className="text-[11px] font-semibold uppercase tracking-[0.32em] text-cyan-300">
              IEEE global
            </p>
            <h2 className="font-display mt-3 text-4xl text-white">
              Advancing technology for humanity.
            </h2>
            <p className="mt-5 leading-relaxed text-slate-400">
              IEEE is a nonprofit association of more than 400,000 members in 160 countries. It
              publishes a third of the world’s technical literature in electrical engineering,
              computer science, and electronics; it also develops standards that quietly run the
              internet, power systems, and consumer devices.
            </p>
            <p className="mt-4 leading-relaxed text-slate-400">
              Student branches are how IEEE shows up on campus. Ours — STB20210 — is the IEEE
              Student Branch of RajaRajeswari College of Engineering under the IEEE Bangalore
              Section (Region 10). We report to a faculty counselor, elect an executive committee
              each year, and host societies that map onto real IEEE technical communities.
            </p>
          </div>
        </div>
      </section>

      <section className="py-10">
        <div className="mx-auto grid max-w-6xl gap-4 px-5 md:grid-cols-3">
          {[
            {
              icon: Compass,
              title: "Mission",
              text: "Give every RRCE student a professional home — papers, prototypes, and a network that survives graduation.",
            },
            {
              icon: Eye,
              title: "Vision",
              text: "Be the Bangalore Section’s most rigorous student branch: measured by Xplore papers, SIGHT impact, and alumni who stay members.",
            },
            {
              icon: HeartHandshake,
              title: "Code",
              text: "IEEE Code of Ethics. Inclusive rooms. Audited budgets. Credit where work was done.",
            },
          ].map((c) => (
            <div key={c.title} className="rounded-3xl border border-white/10 bg-white/[0.03] p-7">
              <c.icon className="h-6 w-6 text-cyan-400" />
              <h3 className="font-display mt-4 text-xl text-white">{c.title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-slate-400">{c.text}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="py-20">
        <div className="mx-auto max-w-5xl px-5">
          <SectionHeading kicker="History" title="Twelve years, written in minutes." />
          <ol className="relative mt-14 space-y-8 border-l border-cyan-400/30 pl-8">
            {TIMELINE.map((t) => (
              <li key={t.year} className="relative">
                <span className="absolute -left-[39px] top-1 h-4 w-4 rounded-full border-2 border-cyan-300 bg-[#050a12]" />
                <p className="font-display text-cyan-300">{t.year}</p>
                <h3 className="mt-1 text-xl text-white">{t.title}</h3>
                <p className="mt-1 text-sm text-slate-400">{t.text}</p>
              </li>
            ))}
          </ol>
        </div>
      </section>

      <section className="pb-24">
        <div className="mx-auto grid max-w-6xl items-center gap-10 px-5 md:grid-cols-[200px_1fr] rounded-3xl border border-white/10 bg-[#0c1826] p-8">
          <img
            src="/images/faculty.jpg"
            alt="Dr. Suresh Menon"
            className="h-48 w-48 justify-self-center rounded-full object-cover ring-2 ring-cyan-400/40"
          />
          <div>
            <p className="text-[11px] uppercase tracking-[0.28em] text-cyan-300">Branch counselor</p>
            <h3 className="font-display mt-2 text-3xl text-white">Dr. Suresh Menon</h3>
            <p className="text-sm text-slate-400">Professor of Electronics & Communication · Senior Member, IEEE</p>
            <p className="mt-4 leading-relaxed text-slate-400">
              “A student branch is not a club. It is the first professional society most of you will
              ever join. We keep the minutes, we keep the ethics, and we keep the door open.”
            </p>
            <p className="mt-4 flex items-center gap-2 text-sm text-slate-500">
              <Landmark className="h-4 w-4 text-gold" /> Department of ECE, RajaRajeswari College of Engineering
            </p>
          </div>
        </div>
      </section>
    </>
  );
}
