export type MembershipStatus = "none" | "pending" | "active";

export type Student = {
  id: string;
  name: string;
  email: string;
  passwordHash: string;
  usn: string;
  phone: string;
  department: string;
  year: string;
  ieeeNumber: string;
  membershipStatus: MembershipStatus;
  societies: string[];
  bio: string;
  createdAt: string;
};

export type PublicStudent = Omit<Student, "passwordHash">;

export type MembershipApp = {
  id: string;
  studentId: string;
  why: string;
  status: "pending" | "approved";
  createdAt: string;
};

export type EventRegistration = {
  id: string;
  studentId: string;
  eventId: string;
  eventTitle: string;
  name: string;
  email: string;
  createdAt: string;
};

export type ContactMessage = {
  id: string;
  name: string;
  email: string;
  topic: string;
  body: string;
  createdAt: string;
};

export type RegisterInput = {
  name: string;
  email: string;
  password: string;
  usn: string;
  phone: string;
  department: string;
  year: string;
};

export type Database = {
  students: Student[];
  memberships: MembershipApp[];
  registrations: EventRegistration[];
  messages: ContactMessage[];
  seeded: boolean;
};
