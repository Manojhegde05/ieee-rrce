export default function SectionHeading({
  kicker,
  title,
  text,
  light = false,
}: {
  kicker: string;
  title: string;
  text?: string;
  light?: boolean;
}) {
  return (
    <div className="mx-auto max-w-3xl text-center">
      <div className="mb-4 inline-flex items-center gap-3">
        <span className="h-px w-8 bg-cyan-400/70" />
        <p className="text-[11px] font-semibold uppercase tracking-[0.32em] text-cyan-300">{kicker}</p>
        <span className="h-px w-8 bg-cyan-400/70" />
      </div>
      <h2 className={`font-display text-3xl font-semibold tracking-tight md:text-5xl ${light ? "text-navy" : "text-white"}`}>
        {title}
      </h2>
      {text && (
        <p className={`mt-4 text-base leading-relaxed md:text-lg ${light ? "text-slate-600" : "text-slate-400"}`}>
          {text}
        </p>
      )}
    </div>
  );
}
