export default function Logo({ compact = false }: { compact?: boolean }) {
  return (
    <div className="flex items-center gap-3">
      <svg viewBox="0 0 48 48" className="h-10 w-10 shrink-0" aria-hidden>
        <defs>
          <linearGradient id="ieeeDiamond" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#00B5E2" />
            <stop offset="100%" stopColor="#00629B" />
          </linearGradient>
        </defs>
        <rect width="48" height="48" rx="10" fill="#002855" />
        <path d="M24 6 L42 24 L24 42 L6 24 Z" fill="none" stroke="#00B5E2" strokeWidth="1.4" />
        <path d="M24 12 L36 24 L24 36 L12 24 Z" fill="url(#ieeeDiamond)" />
        <path d="M24 18 L30 24 L24 30 L18 24 Z" fill="#F4F7FA" />
      </svg>
      <div className="leading-none">
        <div className="font-display text-[1.35rem] font-bold tracking-[0.18em] text-white">IEEE</div>
        {!compact && (
          <div className="mt-1 text-[10px] font-medium uppercase tracking-[0.28em] text-cyan-300/90">
            SB · RRCE
          </div>
        )}
      </div>
    </div>
  );
}
